
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from . import db

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=True)

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Show(db.Model):
    __tablename__ = "shows"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    location = db.Column(db.String(120), nullable=True)
    category = db.Column(db.String(80), nullable=True)
    date = db.Column(db.Date, nullable=True)

    file_name = db.Column(db.String(255), nullable=True)       # nom du fichier sur disque
    file_mimetype = db.Column(db.String(120), nullable=True)   # image/* ou application/pdf
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def is_pdf(self) -> bool:
        return (self.file_mimetype or "").lower().startswith("application/pdf")

    def has_image(self) -> bool:
        return (self.file_mimetype or "").lower().startswith("image/")
